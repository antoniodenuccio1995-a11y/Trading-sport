from pathlib import Path
import sys,os
R=Path('/workspace/scratch/f0027330b816/repo');p=R/'tests/v02v/performance-browser.py';s=p.read_text()
start=s.index("  report['h2hReal']=")
end=s.index("  assert not report['pageerrors']",start)
s=s[:start]+'''  t=time.monotonic();p.reload();p.evaluate('taVInitialized');report['timingsSeconds']['secondWarmReload28k']=round(time.monotonic()-t,3);assert p.evaluate('taFingerprint()')==before;assert p.evaluate('archiveDbGet().then(TARecovery.stable)')==disk
'''+s[end:]
s=s.replace("'performance-browser.json'","'warm-benchmark.json'")
from playwright.sync_api import BrowserType
launch=BrowserType.launch
def local(self,*a,**kw):
 kw['executable_path']='/workspace/scratch/1b6754163016/v02v_audit/runtime/bin/chromium';return launch(self,*a,**kw)
BrowserType.launch=local
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
