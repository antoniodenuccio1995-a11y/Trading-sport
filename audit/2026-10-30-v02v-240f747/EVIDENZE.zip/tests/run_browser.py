from pathlib import Path
import sys,runpy
from playwright.sync_api import BrowserType
launch=BrowserType.launch
def local_launch(self,*args,**kwargs):
 if kwargs.get('executable_path')=='/usr/bin/chromium':kwargs['executable_path']='/workspace/scratch/1b6754163016/v02v_audit/runtime/bin/chromium'
 return launch(self,*args,**kwargs)
BrowserType.launch=local_launch
script=Path(sys.argv[1]).resolve();sys.argv=sys.argv[1:];sys.path.insert(0,str(script.parent));runpy.run_path(str(script),run_name='__main__')
